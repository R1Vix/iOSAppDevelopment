import SwiftUI

struct SalmonShift: Codable {
    let Normal: [SalmonRotation]
}

struct SalmonRotation: Codable, Identifiable {
    var id: String { phaseId }
    let bigBoss: String
    let phaseId: String
    let startTime: Date
    let endTime: Date
    let stage: Int
    let weapons: [Int]
}
