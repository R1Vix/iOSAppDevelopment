import SwiftUI

@Observable class SalmonFetcher {
    var Sitems = [SalmonRotation]()
    
    enum FetchError: Error {
        case invalidURL
        case badRequest
    }
    
    func fetchData(count: Int) async throws {
        let urlString = "https://splatoon.oatmealdome.me/api/v1/three/coop/phases?count=\(count)"
        guard let url = URL(string: urlString) else {
            throw FetchError.invalidURL
        }
        let (data, response) = try await URLSession.shared.data(from: url)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw FetchError.badRequest
        }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let SsearchResponse = try decoder.decode(SalmonShift.self, from: data)
        Sitems = SsearchResponse.Normal
        //print(Sitems)
    }
}
