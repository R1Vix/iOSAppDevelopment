import SwiftUI

struct ItemRow: View {
    let item: normalRotation
    
    var body: some View {
        VStack(alignment: .center) {
            Text(modeText(mode:item.Regular.rule))
                .font(.system(size: 20, design: .rounded))
                .foregroundStyle(.green)
            HStack {
                Image("\(item.Regular.stages[0])")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(5)
                Image("\(item.Regular.stages[1])")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(5)
            }
            HStack {
                Text("\(modeText(mode:item.Bankara.rule))")
                    .fontWeight(.bold)
                    .font(.system(size: 20))
                    .foregroundStyle(.orange)
                Text("(Series)")
                    .font(.system(size: 20, design: .rounded))
                    .foregroundStyle(.orange)
            }
            HStack {
                Image("\(item.Bankara.stages[0])")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(5)
                Image("\(item.Bankara.stages[1])")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(5)
            }
            HStack {
                Text("\(modeText(mode:item.BankaraOpen.rule))")
                    .fontWeight(.bold)
                    .font(.system(size: 20))
                    .foregroundStyle(.orange)
                Text("(Open)")
                    .font(.system(size: 20, design: .rounded))
                    .foregroundStyle(.orange)
                
            }
            HStack {
                Image("\(item.BankaraOpen.stages[0])")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(5)
                Image("\(item.BankaraOpen.stages[1])")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(5)
            }
            HStack {
                Text("\(modeText(mode:item.X.rule))")
                    .fontWeight(.bold)
                    .font(.system(size: 20))
                    .foregroundStyle(.mint)
                Text("(X Battles)")
                    .font(.system(size: 20, design: .rounded))
                    .foregroundStyle(.mint)
            }
            HStack {
                Image("\(item.X.stages[0])")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(5)
                Image("\(item.X.stages[1])")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(5)
            }
            Text("\(item.startTime.formatted()) ~ \(item.endTime.formatted())")
            Spacer()
        }
    }
}

func modeText(mode: String) -> String {
    switch mode {
    case "Paint": "Turf War"
    case "Area": "Splat Zones"
    case "Lift": "Tower Control"
    case "Goal": "Rainmaker"
    case "Clam": "Clam Blitz"
    default: "Unknown"
    }
}

func stageText(stage: Int) -> String {
    switch stage {
    case 1: "Scorch Gorge"
    case 2: "Eeltail Alley"
    case 3: "Hagglefish Market"
    case 4: "Undertow Spillway"
    case 5: "Um'ami Ruins"
    case 6: "Mincemeat Metalworks"
    case 7: "Brinewater Springs"
    case 8: "Barnacle & Dime"
    case 9: "Flounder Heights"
    case 10: "Hammerhead Bridge"
    case 11: "Museum d'Alfonsino"
    case 12: "Mahi-Mahi Resort"
    case 13: "Inkblot Art Academy"
    case 14: "Sturgeon Shipyard"
    case 15: "MakoMart"
    case 16: "Wahoo World"
    case 17: "Humpback Pump Track"
    case 18: "Manta Maria"
    case 19: "Crableg Capital"
    case 20: "Shipshape Cargo Co."
    case 21: "Robo ROM-en"
    case 22: "Bluefin Depot"
    default: "Unknown"
    }
}

#Preview {
    ItemRow(item: normalRotation(Regular: modeStage(rule: "Paint", stages: [2, 21]), Bankara: modeStage(rule: "Area", stages: [16, 17]), BankaraOpen: modeStage(rule: "Clam", stages: [11, 19]), X: modeStage(rule: "Goal", stages: [14, 15]), phaseId: "658117a4af1e62e143b59610", startTime: Date(), endTime: Date()))
}
