import SwiftUI
import UIKit
import AVFoundation
import AVKit

struct Rules: View {
    var body: some View {
        NavigationStack {
            ScrollView(.vertical){
                VStack {
                    Text("THE BASICS")
                        .fontWeight(.heavy)
                        .font(.largeTitle)
                    HStack{
                        VStack{
                            Text("INK")
                                .fontWeight(.heavy)
                                .font(.largeTitle)
                            Text("Splash the stuff all over the place using your weapons. Sure, you can splat opponents, but ink can do so much more. Go ahead—get messy!")
                                .multilineTextAlignment(.leading)
                        }
                        Image("S3Shoot")
                            .resizable()
                            .scaledToFit()
                    }
                    .padding()
                    HStack{
                        Image("S3Swim")
                            .resizable()
                            .scaledToFit()
                        VStack{
                            Text("Dive")
                                .fontWeight(.heavy)
                                .font(.largeTitle)
                            Text("Change into Swim Form to move waaay fast through your own ink color. This’ll let you climb walls covered in ink, zip through fences, refill your ink tank, and more. If you stay still, you’ll be (pretty much) invisible—sneaky, sneaky!")
                                .multilineTextAlignment(.leading)
                        }
                    }
                    .padding()
                    HStack{
                        VStack{
                            Text("Splat")
                                .fontWeight(.heavy)
                                .font(.largeTitle)
                            Text("Take out the other team by blasting them with ink. They’ll be back in action soon, so watch out!")
                                .multilineTextAlignment(.leading)
                        }
                        Image("S3Splat")
                            .resizable()
                            .scaledToFit()
                    }
                    .padding()
                    Text("...And much more!")
                        .font(.caption)
                }
            }
            .navigationTitle("Controls")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview{
    Rules()
}
