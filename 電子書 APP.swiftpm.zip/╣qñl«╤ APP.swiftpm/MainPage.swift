import SwiftUI
import UIKit
import AVFoundation
import AVKit

struct MainPage: View {
    @State private var animationAmount = 0.0
    var body: some View {
        NavigationStack {
            TabView {
                ScrollView(.vertical) {
                    Image("S3CoverArt")
                        .resizable()
                        .scaledToFill()
                        .padding()
                        .opacity(animationAmount)
                        .animation(
                            .easeInOut(duration: 5), value: animationAmount)
                        .onAppear(perform: {
                            animationAmount = 1
                        })
                    /*
                        .onTapGesture {
                            animationAmount = 0
                        }
                    */
                    Spacer(minLength: 20)
                    Link("Watch the trailer (Link)", destination: URL(string: "https://www.youtube.com/watch?v=GUYDXVDLmns")!)
                        .fontWeight(.heavy)
                        .font(.largeTitle)
                        .foregroundStyle(.white)
                        .background(Color(red: 255/255, green: 81/255, blue: 94/255))
                        .rotationEffect(Angle(degrees: 5))
                    VideoPlayer(player: AVPlayer(url: Bundle.main.url(forResource: "S3Trailer", withExtension: "mp4")!))
                        .scaledToFill()
                    HStack {
                        Spacer(minLength: 10)
                        VStack(alignment: .leading) {
                            Text("INK UP THE")
                                .font(.title)
                                .fontWeight(.bold)
                            Text("SPLATLANDS")
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundStyle(Color(red: 255/255, green: 200/255, blue: 134/255))
                            Text("Enter a sun-scorched desert inhabited by\nbattle-hardened Inklings and Octolings. \nInk, dive, swim, and splat your way to the top!")
                        }
                        NavigationLink(destination: {
                            Splatsville()
                        }, label: {
                            VStack{
                                Image("S3ScorchGorge")
                                    .resizable()
                                    .scaledToFit()
                                Text("Welcome to Splatsville")
                                    .foregroundStyle(Color.black)
                                    .bold()
                                    .background(Color(red: 255/255, green: 134/255, blue: 255/255))
                            }
                            
                        })
                    }
                    HStack{
                        NavigationLink {
                            Rules()
                        } label: {
                            VStack{
                                Text("How to play, game modes, and all that")
                                    .fontWeight(.bold)
                                    .foregroundStyle(Color.white)
                                    .background(Color(red: 160/255, green: 102/255, blue: 255/255))
                                Image("S3Rules")
                                    .resizable()
                                    .scaledToFit()
                            }
                        }
                        Spacer(minLength: 10)
                        NavigationLink {
                            Weapons()
                        } label: {
                            VStack{
                                Text("Make a splash with the latst weapons and gear")
                                    .fontWeight(.bold)
                                    .foregroundStyle(Color.black)
                                    .background(Color(red: 255/255, green: 255/255, blue: 106/255))
                                Image("S3Weapons")
                                    .resizable()
                                    .scaledToFit()
                            }
                            
                        }
                    }
                }
                .tabItem {
                    Image(systemName: "house")
                }
                
                VStack {
                    let news = [
                        Data(image: "S3SplatfestHandshake", title: "EXTEND YOUR HOSPITALITY WITH A LITTLE INK IN THE NEXT SPLATOON 3 SPLATFEST!"),
                        Data(image: "S3OneYear", title: "CELEBRATE ONE YEAR OF SPLATOON 3 (AND A BRAND-NEW SEASON)!"),
                        Data(image: "S3DrizzleSeason", title: "SQUID RESEARCH LAB REPORT: DRIZZLE SEASON, SPLATFEST, AND MORE"),
                        Data(image: "S3BigRun", title: "BIG RUN - UM'AMI RUINS"),
                        Data(image: "S3SplatfestIceCream", title: "MONEY, FAME, OR LOVE? PICK A SIDE AND BATTLE IT OUT IN THE NEXT SPLATFEST!"),
                        Data(image: "S3SizzleSeason", title: "SPLATOON 3 SIZZLE SEASON ADDS NEW WEAPONS, STAGES, CHALLENGES, AND MORE!")
                    ]
                    
                    let columns = [GridItem()]
                    
                    ScrollView{
                        LazyVGrid(columns: columns) {
                            VStack{
                                ForEach(news.indices, id: \.self) { item in
                                    NewsView(data: news[item])
                                }
                            }
                        }
                    }
                }
                .tabItem { 
                    Image(systemName: "newspaper")
                }
            }
            .navigationTitle("Splatoon 3")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct NewsView: View {
    let data: Data
    
    var body: some View{
        VStack{
            Image(data.image)
                .resizable()
                .scaledToFit()
                .clipped()
            Text(data.title)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
        }
        .padding(30)
    }
}

struct Data{
    let image: String
    let title: String
}
