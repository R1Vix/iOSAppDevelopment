import SwiftUI

@main
struct MyApp: App {
    @State private var fetcher = DataFetcher()
    @State private var Sfetcher = SalmonFetcher()
    
    var body: some Scene {
        WindowGroup {
            Splatoon_3()
                .environment(fetcher)
                .environment(Sfetcher)
        }
    }
}
