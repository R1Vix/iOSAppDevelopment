import SwiftUI
import UIKit
import TipKit

struct Splatoon_3: View {
    
    @Environment(DataFetcher.self) var fetcher
    @Environment(SalmonFetcher.self) var Sfetcher
    @State private var showError = false
    @State private var error: Error?
    
    @State private var searchText = ""
    
    
    
    var tip = InlineTip()
    
   
    
    init() {
        try? Tips.configure([.displayFrequency(.daily)])
        let fontURL = Bundle.main.url(forResource: "BlitzMain", withExtension: "otf")! as CFURL
        CTFontManagerRegisterFontsForURL(fontURL, .process, nil)
    }
    
    var body: some View {
        var searchresult: [normalRotation] {
            if searchText.isEmpty {
                fetcher.items
            } else {
                fetcher.items.filter {
                    $0.phaseId.contains(searchText)
                }
            }
        }
    
        TabView {
            //Page 1
            NavigationStack {
                List {
                    ForEach(searchresult) { item in
                        NavigationLink {
                            ItemDetail(item: item)
                        } label: {
                            VStack {
                                ItemRow(item: item)
                                    .listRowSeparator(.hidden)
                                TipView(tip, arrowEdge: .top)
                            }
                        }
                    }
                }
                .task {
                    if fetcher.items.isEmpty {
                        do {
                            try await fetcher.fetchData(count: 12)
                        }
                        catch {
                            print(error)
                            self.error = error
                            showError = true
                        }
                    }
                }
                
                .onChange(of: searchText, {
                    Task {
                        do {
                            try await fetcher.fetchData(count: 12)
                        }
                        catch {
                            print(error)
                            self.error = error
                            showError = true
                        }
                    }
                })
                .refreshable {
                    do {
                        try await fetcher.fetchData(count: 12)
                    }
                    catch {
                        self.error = error
                        showError = true
                    }
                }
                .alert(error?.localizedDescription ?? "", isPresented: $showError, actions: {})
                
                .overlay {
                    if searchresult.isEmpty {
                        ContentUnavailableView(label: {
                            ProgressView()
                        }, description: {
                            Text("Loading...")
                        })
                    }
                }
            }
            .searchable(text: $searchText)
            .tabItem {
                Image("Ranked")
            }
            
            
            //Page 2
            
            List {
                ForEach(Sfetcher.Sitems) { item in
                    SalmonRow(Sitem: item)
                }
            }
            .task {
                if Sfetcher.Sitems.isEmpty {
                    do {
                        try await Sfetcher.fetchData(count: 5)
                    }
                    catch {
                        print(error)
                        self.error = error
                        showError = true
                    }
                }
            }
            .refreshable {
                do {
                    try await Sfetcher.fetchData(count: 5)
                }
                catch {
                    self.error = error
                    showError = true
                }
            }
            .alert(error?.localizedDescription ?? "", isPresented: $showError, actions: {})
            
            .overlay {
                if searchresult.isEmpty {
                    ContentUnavailableView(label: {
                        ProgressView()
                    }, description: {
                        Text("Loading...")
                    })
                }
            }
            .tabItem {
                Image("Salmon")
            }
        }
    }
}

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        //Do any additional setup after loading the view.
    }
    
    func checkForPermission(){
        let notificationCenter = UNUserNotificationCenter.current()
        notificationCenter.getNotificationSettings { settings in
            switch settings.authorizationStatus {
            case .notDetermined:
                notificationCenter.requestAuthorization(options: [.alert, .sound]) { didAllow, error in
                    if didAllow {
                        self.dispatchNotification()
                    }
                }
            case .denied:
                return
            case .authorized:
                self.dispatchNotification()
            default:
                return
            }
        }
    }
    
    func dispatchNotification() {
        let identifier = "daily-reminder"
        let title = "Time to dive!"
        let body = "Check out the current rotations."
        let hour = 12
        let minute = 00
        let isDaily = true
        
        let notificationCenter = UNUserNotificationCenter.current()
        
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        
        let calendar = Calendar.current
        var dateComponents = DateComponents(calendar: calendar, timeZone: TimeZone.current)
        dateComponents.hour = hour
        dateComponents.minute = minute
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: isDaily)
        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
        
        notificationCenter.removePendingNotificationRequests(withIdentifiers: [identifier])
        notificationCenter.add(request)
    }
}

struct InlineTip: Tip {
    var title: Text {
        Text("Warning! First match of the day")
    }
    var message: Text? {
        Text("Mabye warm up with some casual turf war before diving into Ranked?")
    }
    var image: Image? {
        Image(systemName: "exclamationmark.triangle")
    }
}
