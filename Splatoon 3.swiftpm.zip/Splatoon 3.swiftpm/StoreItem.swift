import SwiftUI

struct StoreItem: Codable{
    let normal: [normalRotation]
}

struct normalRotation: Codable, Identifiable{
    var id: String { phaseId }
    let Regular: modeStage
    let Bankara: modeStage
    let BankaraOpen: modeStage
    let X: modeStage
    let phaseId: String
    let startTime: Date
    let endTime: Date
}

struct modeStage: Codable {
    let rule: String
    let stages: [Int]
}
