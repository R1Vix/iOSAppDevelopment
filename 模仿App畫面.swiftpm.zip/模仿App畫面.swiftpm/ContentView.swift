import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            //目標圖片
            Image("target")
                .resizable()
                .padding()
                .opacity(0)
            VStack(spacing: 7) {
                //頂部狀態列
                Image("top")
                    .resizable()
                    .frame(height: 80)
                //Google的logo
                Text("Google")
                    .fontWeight(.bold)
                    .font(.title)
                ZStack {
                    //搜尋欄
                    Capsule()
                        .fill(.gray)
                        .frame(width: 320, height: 50)
                    Text("搜尋")
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                        .padding()
                        .offset(x: -110)
                    Image(systemName: "mic")
                        .offset(x: 80)
                    Image(systemName: "camera")
                        .offset(x: 130)
                }
                HStack {
                    //小功能一
                    ZStack {
                        Capsule()
                            .fill(.gray)
                            .frame(width: 180, height: 50)
                        HStack {
                            ZStack {
                                Circle()
                                    .fill(.black)
                                    .frame(width: 35, height: 35)
                                Image(systemName: "scanner")
                            }
                            VStack {
                                Text("搜尋相片內容")
                                    .font(.caption)
                                    .offset(x: -18)
                                Text("直接在相機膠卷中搜尋")
                                    .font(.caption2)
                            }
                        }
                    }
                    //小功能二
                    ZStack {
                        Capsule()
                            .fill(.gray)
                            .frame(width: 135, height: 50)
                        HStack {
                            ZStack {
                                Circle()
                                    .fill(.black)
                                    .frame(width: 35, height: 35)
                                Image(systemName: "house")
                            }
                            VStack {
                                Text("家庭作業幫手")
                                    .font(.caption)
                                Text("使用相機")
                                    .font(.caption2)
                                    .offset(x: -15)
                            }
                        }
                    }
                }
                //新聞圖片
                Image("baseball")
                    .resizable()
                    .frame(width: 320, height: 120)
                    .cornerRadius(10)
                //標題
                Text("亞運棒球》中國大陸棒球史上的歷史一役分組預賽1比O完封日本")
                    .bold()
                    .frame(width: 320)
                //新聞圖片
                Image("storm")
                    .resizable()
                    .frame(width: 320, height: 130)
                    .cornerRadius(10)
                //底部列
                Image("bottom")
                    .resizable()
                    .frame(height: 70)
            }
        }
    }
}
