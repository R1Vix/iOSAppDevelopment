import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit


struct Weapons: View {
    
    var body: some View {
        NavigationStack {
            VStack {
                VStack{
                    Text("WEAPONS AND GEAR")
                        .fontWeight(.heavy)
                        .font(.largeTitle)
                        .rotationEffect(.degrees(-10))
                        .padding()
                    Text("Talk about the weapon diversity!")
                        .padding()
                        .multilineTextAlignment(.leading)
                }
                .frame(height: 200)
                .background(Image("S3Battle")
                    .resizable()
                    .opacity(0.5))
            }
            let images = ["Weapon_Splattershot",
                          "Weapon_Dynamo",
                          "Weapon_E-liter",
                          "Weapon_Machine",
                          "Weapon_Hydra",
                          "Weapon_Dualies",
                          "Weapon_Brella",
                          "Weapon_Range",
                          "Weapon_Inkbrush",
                          "Weapon_Tri-Stringer",
                          "Weapon_Wiper"
            ]
            ScrollView(.vertical){
                ForEach(images.indices, id: \.self) { item in
                    WeaponView(image: images[item])
                }
            }
            .navigationTitle("Weapons & Gear")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct WeaponView: View {
    @State private var opacity: Double = 0
    @State private var scale: Double = 1
    let image: String
    var body: some View {
        Image(image)
            .resizable()
            .scaledToFit()
            .opacity(opacity)
            .scaleEffect(scale)
            .animation(.easeInOut(duration: 3), value: opacity)
            .onAppear {
                opacity = 1
            }
            .animation(.easeInOut(duration: 3), value: scale)
            .onTapGesture {
                scale = 1.2
            }
            .padding(20)
    }
}

class ViewController: UIViewController {
    
    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let url = URL(string: "https://www.youtube.com/embed/nBUVetiLhGw")!
        let request = URLRequest(url: url)
        webView.load(request)
    }
}

#Preview{
    Weapons()
}
