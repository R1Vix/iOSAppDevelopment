import SwiftUI

struct ItemDetail: View {
    let item: normalRotation
    
    var body: some View {
        ScrollView(.vertical) {
            VStack(alignment: .center) {
                HStack {
                    Text("\(modeText(mode:item.Regular.rule)) ")
                        .font(.system(size: 20, design: .rounded))
                        .foregroundStyle(.green)
                    ShareLink(item: "Rules: \(modeText(mode:item.Regular.rule))\nStages: \(stageText(stage:item.Regular.stages[0])), \(stageText(stage:item.Regular.stages[1]))\nfrom \(item.startTime.formatted()) to \(item.startTime.formatted())")
                }
                HStack {
                    VStack {
                        Image("\(item.Regular.stages[0])")
                            .resizable()
                            .scaledToFit()
                        Text("\(stageText(stage:item.Regular.stages[0]))")
                            .font(.caption2)
                            .fixedSize()
                            .lineLimit(1)
                        Text("Win Rate: \(Int.random(in: 10 ..< 90))%")
                    }
                    VStack {
                        Image("\(item.Regular.stages[1])")
                            .resizable()
                            .scaledToFit()
                        Text("\(stageText(stage:item.Regular.stages[1]))")
                            .font(.caption2)
                            .lineLimit(1)
                        Text("Win Rate: \(Int.random(in: 10 ..< 90))%")
                    }
                }
                Spacer()
                HStack {
                    Text("Anarcy (Series),")
                        .font(.system(size: 20, design: .rounded))
                        .foregroundStyle(.orange)
                    Text("\(modeText(mode:item.Bankara.rule)) ")
                        .fontWeight(.bold)
                        .font(.system(size: 20))
                        .foregroundStyle(.orange)
                    ShareLink(item: "Mode: Anarcy (Series)\nRules: \(modeText(mode:item.Bankara.rule))\nStages: \(stageText(stage:item.Bankara.stages[0])), \(stageText(stage:item.Bankara.stages[1]))\nfrom \(item.startTime.formatted()) to \(item.startTime.formatted())")
                }
                HStack {
                    VStack {
                        Image("\(item.Bankara.stages[0])")
                            .resizable()
                            .scaledToFit()
                        Text("\(stageText(stage:item.Bankara.stages[0]))")
                            .font(.caption2)
                            .lineLimit(1)
                        Text("Win Rate: \(Int.random(in: 10 ..< 90))%")
                    }
                    VStack {
                        Image("\(item.Bankara.stages[1])")
                            .resizable()
                            .scaledToFit()
                        Text("\(stageText(stage:item.Bankara.stages[1]))")
                            .font(.caption2)
                            .lineLimit(1)
                        Text("Win Rate: \(Int.random(in: 10 ..< 90))%")
                    }
                }
                Spacer()
                HStack {
                    Text("Anarcy (Open),")
                        .font(.system(size: 20, design: .rounded))
                        .foregroundStyle(.orange)
                    Text("\(modeText(mode:item.BankaraOpen.rule)) ")
                        .fontWeight(.bold)
                        .font(.system(size: 20))
                        .foregroundStyle(.orange)
                    ShareLink(item: "Mode: Anarcy (Open)\nRules: \(modeText(mode:item.BankaraOpen.rule))\nStages:  \(stageText(stage:item.BankaraOpen.stages[0])), \(stageText(stage:item.BankaraOpen.stages[1]))\nfrom \(item.startTime.formatted()) to \(item.startTime.formatted())")
                }
                HStack {
                    VStack {
                        Image("\(item.BankaraOpen.stages[0])")
                            .resizable()
                            .scaledToFit()
                        Text("\(stageText(stage:item.BankaraOpen.stages[0]))")
                            .font(.caption2)
                            .lineLimit(1)
                        Text("Win Rate: \(Int.random(in: 10 ..< 90))%")
                    }
                    VStack {
                        Image("\(item.BankaraOpen.stages[1])")
                            .resizable()
                            .scaledToFit()
                        Text("\(stageText(stage:item.BankaraOpen.stages[1]))")
                            .font(.caption2)
                            .lineLimit(1)
                        Text("Win Rate: \(Int.random(in: 10 ..< 90))%")
                    }
                }
                Spacer()
                HStack {
                    Text("X Battle,")
                        .font(.system(size: 20, design: .rounded))
                        .foregroundStyle(.mint)
                    Text("\(modeText(mode:item.X.rule)) ")
                        .fontWeight(.bold)
                        .font(.system(size: 20))
                        .foregroundStyle(.mint)
                    ShareLink(item: "Mode: X battle\nRules: \(modeText(mode:item.X.rule))\nStages:  \(stageText(stage:item.X.stages[0])), \(stageText(stage:item.X.stages[1]))\nfrom \(item.startTime.formatted()) to \(item.startTime.formatted())")
                }
                HStack {
                    VStack {
                        Image("\(item.X.stages[0])")
                            .resizable()
                            .scaledToFit()
                        Text("\(stageText(stage:item.X.stages[0]))")
                            .font(.caption2)
                            .lineLimit(1)
                        Text("Win Rate: \(Int.random(in: 10 ..< 90))%")
                    }
                    VStack {
                        Image("\(item.X.stages[1])")
                            .resizable()
                            .scaledToFit()
                        Text("\(stageText(stage:item.X.stages[1]))")
                            .font(.caption2)
                            .lineLimit(1)
                        Text("Win Rate: \(Int.random(in: 10 ..< 90))%")
                    }
                }
                Spacer()
                VStack(alignment: .leading){
                    Text("Starts: \(item.startTime)")
                    Text("Ends: \(item.endTime)")
                    HStack {
                        Text("PhaseId: \(item.phaseId)")
                        ShareLink(item: "\(item.phaseId)")
                    }
                }
            }
        }
        .padding()
    }
}
