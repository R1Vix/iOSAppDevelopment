import SwiftUI
import UIKit
import AVFoundation
import AVKit

struct Splatsville: View {
    var body: some View {
        NavigationStack {
            ScrollView(.vertical){
                VStack {
                    Text("WELCOME TO")
                        .fontWeight(.heavy)
                        .font(.largeTitle)
                        .foregroundStyle(Color.orange)
                    Text("SPLATSVILLE")
                        .fontWeight(.heavy)
                        .font(.largeTitle)
                    Text("Splatsville, the city of chaos, is the adrenaline-fueled heart of the dusty Splatlands.\nThe folks who live here are a little rowdier than what you might find in far-away Inkopolis.")
                        .padding()
                        .multilineTextAlignment(.leading)
                    TabView {
                        ExtractedView(image: "S3Splatsville1")
                        ExtractedView(image: "S3Splatsville2")
                        ExtractedView(image: "S3Splatsville3")
                        ExtractedView(image: "S3Splatsville4")
                        ExtractedView(image: "S3Splatsville5")
                        ExtractedView(image: "S3Splatsville6")
                        ExtractedView(image: "S3Splatsville7")
                        ExtractedView(image: "S3Splatsville8")
                    }
                    .frame(minHeight: 500)
                    .tabViewStyle(.page)
                    HStack{
                        VStack{
                            Text("THIS IS AN INKLING")
                                .fontWeight(.heavy)
                                .font(.title)
                                .foregroundStyle(Color.yellow)
                            Text("These trendy cephalopods can transform from kid to squid...and back. (Whoa.)")
                        }
                        Image("S3Inkling")
                            .resizable()
                            .scaledToFit()
                    }
                    .padding()
                    HStack{
                        Image("S3Octoling")
                            .resizable()
                            .scaledToFit()
                        VStack{
                            Text("...AND THIS IS AN OCTOLING")
                                .fontWeight(.heavy)
                                .font(.title)
                                .foregroundStyle(Color.purple)
                            Text("Same deal, different species. Play as either!")
                        }
                    }
                    .padding()
                }
                .navigationTitle("Splatsville")
                .navigationBarTitleDisplayMode(.inline)
            }
        }
    }
}

#Preview{ 
    Splatsville()
}

struct ExtractedView: View {
    let image: String
    var body: some View {
        Image(image)
            .resizable()
            .scaledToFit()
    }
}
